package com.example.quizapp

import com.example.quizapp.R
import com.example.quizapp.Question


object Constants {

    const val userName: String = "user_name"
    const val total_Questions: String = "total_Questions"
    const val correct_Answers: String = "correct_Answers"

    fun getQuestions(): ArrayList<Question>{
        val questionList = ArrayList<Question>()
        val que1 = Question(
            1,
        "1 + 1",
        "1",
        "3",
        "2",
        "4",
        3
        )
        questionList.add(que1)

        val que2 = Question(2,
            "2 + 1",
            "1",
            "3",
            "2",
            "4",
            2
        )
        questionList.add(que2)

        val que3 = Question(3,
            "1 + 0",
            "1",
            "3",
            "2",
            "4",
            1
        )
        questionList.add(que3)

        val que4 = Question(4,
            "1 + 3",
            "1",
            "3",
            "2",
            "4",
            4
        )
        questionList.add(que4)

        val que5 = Question(5,
            "1 + 4",
            "1",
            "5",
            "2",
            "4",
            2
        )
        questionList.add(que5)

        val que6 = Question(6,
            "2 + 2",
            "1",
            "3",
            "2",
            "4",
            4
        )
        questionList.add(que6)

        val que7 = Question(7,
            "2 + 5",
            "7",
            "6",
            "8",
            "4",
            1
        )
        questionList.add(que7)

        val que8 = Question(8,
            "1 + 10",
            "13",
            "12",
            "11",
            "9",
            3
        )
        questionList.add(que8)

        val que9 = Question(9,
            "4 + 5",
            "8",
            "7",
            "10",
            "9",
            4
        )
        questionList.add(que9)

        val que10 = Question(10,
            "5 + 9",
            "13",
            "15",
            "14",
            "16",
            3
        )
        questionList.add(que10)

        return  questionList
    }

}