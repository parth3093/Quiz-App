package com.example.quizapp
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val startButton = findViewById<View>(R.id.btn_start) as Button
        val email = findViewById<View>(R.id.email_address) as EditText
        val name = findViewById<View>(R.id.name) as EditText

        startButton.setOnClickListener {
            if (email.text.toString().isEmpty() && name.text.toString().isEmpty()){
                Toast.makeText(this,
                    "Please enter your name and email address",
                    Toast.LENGTH_SHORT).show()
            } else if (name.text.toString().isEmpty()){
                Toast.makeText(this,
                    "Please enter your name",
                    Toast.LENGTH_SHORT).show()
            } else if(email.text.toString().isEmpty()){
                Toast.makeText(this,
                    "Please enter your email address",
                    Toast.LENGTH_SHORT).show()
            } else{
                val intent = Intent(this,QuizQuestionActivity::class.java)
                intent.putExtra(Constants.userName, name.text.toString())
                startActivity(intent)
                finish()
            }

        }
    }

}